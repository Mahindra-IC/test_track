from flask import Flask, send_file, render_template, request, redirect, url_for, jsonify
import pymysql
from flask_cors import CORS
import pandas as pd
import datetime

app = Flask(__name__)
CORS(app)

latest_id = 0  # Initialize a variable to track the latest primary key
n = 1
# Function to retrieve the latest row from the database
def get_last_row_barcodes():
    global latest_id  # Access the global variable
    global n
    try:
        # Database connection details
        db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
        cursor = db.cursor()
        q1="SELECT id FROM authorized WHERE left_at IS NOT NULL and KMS_out is null ORDER BY left_at DESC LIMIT 1"
        # Query to fetch the latest id from the database table
        
        cursor.execute(q1)
        id1=cursor.fetchone()
        id2=None
        print (id1)
        if(id1 is not None):
            id2=id1[0]
            print(id2)
        print("bfr try")
        try:
            print("inside try")
            query_id = "SELECT id FROM authorized where KMS is null ORDER BY id LIMIT 1" #"SELECT id FROM authorized ORDER BY id DESC LIMIT 1"
            cursor.execute(query_id)
            last_id = cursor.fetchone()[0]  # Get the latest id
        except:
            print("inside except")
            q2= "SELECT VIN, name_id, created_at, left_at FROM authorized WHERE id = %s"
            cursor.execute(q2, id1)
            row=cursor.fetchone()
            print(row)
            barcode1, barcode2, created_at, left_at=row
            db.close()
            return{
                "barcode1": barcode1,
                "barcode2": barcode2,
                "id": id2,  #Include the id for identifying the entry
                "left_at": left_at,
                "created_at": created_at,
                "out":1
            }
            pass
        print("afterlast")
        # query_id1 = "SELECT id FROM authorized where KMS_out is null and left_at is not u ORDER BY id desc LIMIT 1" #"SELECT id FROM authorized ORDER BY id DESC LIMIT 1"
        # cursor.execute(query_id1)
        # last_id1 = cursor.fetchone()[0]
        print("hi")
        print("hi2")
        cursor.execute(q1)
        id1=cursor.fetchone()
        print("HI")
        # print(id1)
        id2=None
        if(id1 is not None):
            id2=id1[0]
            print(id2)
        print("ss")

        # query_barcodes1 = "SELECT VIN, name_id, created_at FROM authorized WHERE id = %s"
        # cursor.execute(query_barcodes1, (last_id,))
        # lr = cursor.fetchone()
        # barcode11, barcode22  = lr
        query_barcodes = "SELECT VIN, name_id, created_at FROM authorized WHERE id = %s"
        cursor.execute(query_barcodes, (last_id,))
        last_row1 = cursor.fetchone()
        vip=last_row1[1]
        print(vip)
        if vip == "VIPPASS":
            print("inside vip")
            # vip_entry(id)
            # query_barcodes2 = "SELECT VIN, name_id, created_at FROM authorized WHERE name_id = %s"
            # cursor.execute(query_barcodes2, (last_id,))
            # print("abv fetch")
            # last_row1 = cursor.fetchone()
            print("Abv return")
            print(last_row1)
            return {
                "barcode1": last_row1[0],
                "barcode2": last_row1[1],
                "id": last_id,  #Include the id for identifying the entry
                "created_at": last_row1[2],
                "out":0
            }

        # Check if the latest id has changed
        if last_id or (n==0):
            n=1
            print("insdei")
            print("sinids")
            latest_id = last_id  # Update the latest_id
            # Query to fetch the latest row based on the latest id
            
            cursor.execute(query_barcodes, (last_id,))
            last_row = cursor.fetchone()

            db.close()  # Close the database connection
            id=last_id
            # if vip == "VIPPASS":
            #     print("inside vip")
            #     vip_entry(id)
            #     cursor.execute(query_barcodes, (id,))
            #     last_row1 = cursor.fetchone()
            #     return {
            #         "barcode1": last_row1[0],
            #         "barcode2": last_row1[1],
            #         "id": id,  #Include the id for identifying the entry
            #         "created_at": last_row1[2],
            #         "out":0
            #     }
            if last_row and last_row[1] != "VIPPASS":
                barcode1, barcode2, created_at,  = last_row
                if barcode2 is None:
                    n=0
                return {
                    "barcode1": barcode1,
                    "barcode2": barcode2,
                    "id": id,  #Include the id for identifying the entry
                    "created_at": created_at,
                    "out":0
                }
            else:
                return {"message": "No data available"}
            
        elif id2 is not None:
            if id2 is not None:
                print("inside id2")
                q2= "SELECT VIN, name_id, created_at, left_at FROM authorized WHERE id = %s"
                cursor.execute(q2, (id2,))
                row=cursor.fetchone()
                print(row)
                barcode1, barcode2, created_at, left_at=row
                db.close()
                return{
                    "barcode1": barcode1,
                    "barcode2": barcode2,
                    "id": id2,  #Include the id for identifying the entry
                    "left_at": left_at,
                    "created_at": created_at,
                    "out":1
                }
        # elif last_id1:
        #     print(last_id1+" insde")
        #     q2= "SELECT VIN, name_id, created_at, left_at FROM authorized WHERE id = %s"
        #     cursor.execute(q2, (last_id1,))
        #     row=cursor.fetchone()
        #     print(row)
        #     barcode1, barcode2, created_at, left_at=row
        #     db.close()
        #     return{
        #         "barcode1": barcode1,
        #         "barcode2": barcode2,
        #         "id": id2,  #Include the id for identifying the entry
        #         "left_at": left_at,
        #         "created_at": created_at,
        #         "out":1
        #     }


        
        
        
    except Exception as e:
        return {'error': str(e)}

@app.route('/barcodes')
def fetch_last_row_barcodes():
    last_row_barcodes = get_last_row_barcodes()
    print(last_row_barcodes)
    return jsonify(last_row_barcodes)

@app.route('/barcodes1')
def fetch_count():
    db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
    cursor = db.cursor()
    query2= "Select count(*) from authorized where left_at is null"
    cursor.execute(query2)
    count=cursor.fetchone()[0]
    j= {
        "count":count,
        }
    return jsonify(j)
# def fetch_out_kms():
#     db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
#     cursor = db.cursor()
#     q1="SELECT id FROM authorized WHERE left_at IS NOT NULL and KMS_out is null ORDER BY left_at DESC LIMIT 1"
#     # Query to fetch the latest id from the database table
#     cursor.execute(q1)
#     id1=cursor.fetchone()[0]
#     if id1:
#         q2= "SELECT VIN, name_id, created_at FROM authorized WHERE id = %s"
#         cursor.execute(q2, (id1,))
#         row=cursor.fetchone()
#         barcode1, barcode2, created_at=row
#         db.close()
#         return{
#              "barcode1": barcode1,
#             "barcode2": barcode2,
#             "id": id1,  #Include the id for identifying the entry
#             "created_at": created_at,
#             "out":1
#         }



@app.route('/vip/<entry_id>', methods=['GET', 'POST'])
def vip_entry(entry_id):
    if request.method == 'POST':
        name = request.form['name']
        token = request.form['token']
        # Update the database with kilometers using entry_id
        try:
            db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
            cursor = db.cursor()

            sql_update = "UPDATE authorized SET name_id = %s WHERE id = %s"
            cursor.execute(sql_update, (token+"_"+name, entry_id))

            db.commit()
            db.close()
            
            return redirect(url_for('success'))
        
        except Exception as e:
            return {'error': str(e)}

    return render_template('vip_entry.html')



@app.route('/kilometers/<entry_id>', methods=['GET', 'POST'])
def kilometers_entry(entry_id):
    if request.method == 'POST':
        kilometers = request.form['kilometers']
        
        # Update the database with kilometers using entry_id
        try:
            db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
            cursor = db.cursor()

            sql_update = "UPDATE authorized SET KMS = %s WHERE id = %s"
            cursor.execute(sql_update, (kilometers, entry_id))

            db.commit()
            db.close()
            
            return redirect(url_for('success'))
        
        except Exception as e:
            return {'error': str(e)}

    return render_template('kilometers_entry.html')

@app.route('/kilometers_out/<entry_id>', methods=['GET', 'POST'])
def kilometers_exit(entry_id):
    if request.method == 'POST':
        kilometers = request.form['kilometers']
        
        # Update the database with kilometers using entry_id
        try:
            db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
            cursor = db.cursor()

            sql_update = "UPDATE authorized SET KMS_out = %s WHERE id = %s"
            cursor.execute(sql_update, (kilometers, entry_id))

            db.commit()
            db.close()
            
            return redirect(url_for('success'))
        
        except Exception as e:
            return {'error': str(e)}

    return render_template('kilometers_exit.html')

@app.route('/success')
def success():
    #print("Kilometers successfully entered!")
    return render_template('1.html')

@app.route('/success1')
def success1():
    #print("Kilometers successfully entered!")
    return render_template('1.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Process the form data here
        username = request.form['username']
        password = request.form['password']

        # Add your authentication logic here
        hardcodedUsername = "admin"
        hardcodedPassword = "admin"

        # Redirect to 1.html if authentication is successful
        if(username==hardcodedUsername and password==hardcodedPassword):
            return redirect(url_for('success'))

    # Render the login form for GET requests
    return render_template('2.html')

@app.route('/export')
def exporte():
    config = {
        'user': 'root',
        'password': '1234',
        'host': 'localhost',
        'database': 'db',
    }

    # Establishing MySQL Connection
    try:
        conn = pymysql.connect(**config)
        cursor = conn.cursor()

        # Fetching data from MySQL
        query = "SELECT * FROM authorized WHERE VIN LIKE 'ma1%' AND CHAR_LENGTH(VIN) = 17"
        cursor.execute(query)

        # Extracting data into a pandas DataFrame
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        df = pd.DataFrame(data, columns=columns)
        #df['name_id'] = df['name_id'].str[2:]
        # Exporting data to Excel
        date = datetime.datetime.now().strftime("%Y-%m-%d")
        excel_file = "Test_track_"+date+".xlsx"
        df.to_excel(excel_file, index=False)

        print(f"Data successfully exported to '{excel_file}'")
        # alert_script = "<script>alert('Data successfully exported!');</script>"

        # return redirect(url_for('success')) + alert_script
        return send_file(excel_file, as_attachment=True, download_name=f"Test_track_{date}.xlsx")

    except Exception as e:
        print (f'\'error\': {str(e)}')
        return jsonify({'message': 'Export failed. Please close the excel sheet if open and try again'})

    finally:
        # Closing MySQL Connection
        if 'connection' in locals() and conn.open:
            conn.close()
    #return redirect(url_for('success'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
