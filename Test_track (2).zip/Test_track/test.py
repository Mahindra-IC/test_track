import keyboard
import pymysql
db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
cursor=db.cursor()
barcode = ""  # Variable to store the barcode string
barcode2=""
f=0
def on_key_event(event):
    global f
    global barcode

    if f==0:
        if event.event_type == keyboard.KEY_DOWN:
            char = event.name
            barcode += char
            print(char, end='', flush=True)  # Print the typed character without newline

            if len(barcode) == 8:
                print("\nCaptured barcode:", barcode)
                # name_id=barcode
                sql1= "INSERT INTO authorized (name_id) VALUES (%s)"
                cursor.execute(sql1,str(barcode))
                  # Reset barcode after storing 8 characters
                f=1
    
    global barcode2

    if f==1:
        if event.event_type == keyboard.KEY_DOWN:
            char = event.name
            barcode2 += char
            print(char, end='', flush=True)  # Print the typed character without newline

            if len(barcode2) == 8:
                print("\nCaptured barcode2:", barcode2)
                # name_id=barcode
                sql1= "UPDATE authorized SET VIN= %s where name_id=%s"
                cursor.execute(sql1,(str(barcode2), str(barcode)))
                db.commit()
                barcode = ""
                barcode2 = ""  # Reset barcode after storing 8 characters
                f=0

print("Type the barcode (press 'esc' to finish):")

keyboard.on_press(on_key_event)

while True:
    if keyboard.is_pressed('esc'):  # Exit loop if 'esc' is pressed
        break

keyboard.unhook_all()  # Stop listening for events
