from pynput import keyboard
import pymysql
import time
import re
import cryptography

db = pymysql.connect(host='localhost', user='root', password='1234', db='db')
cursor = db.cursor()

barcode = ""  # Variable to store the barcode string
barcode2 = ""
f = 0
last_key_time = 0
bc = ""
ft=0
tt=time.time()

def on_release(key):
    global tt, f, ft, barcode, barcode2, last_key_time, bc

    if key == keyboard.Key.esc:
        return False  # Stop listener when 'esc' key is pressed

    try:
        char = key.char  # Get the character representation of the key
        if char is not None and  re.match('^[a-zA-Z0-9#]+$', char):
            current_time = time.time()

            if (current_time - last_key_time) > 2.5:  # Check if it's been more than 1 second
                # Reset barcodes if time exceeded
                barcode = ""
                barcode2 = ""

            last_key_time = current_time  # Update the last key press time

            if f == 0:
                barcode += char
                print(char, end='', flush=True)  # Print the typed character without newline

                if len(barcode) == 17 and barcode.startswith("ma1"):
                    ft=0
                    print("\nCaptured barcode1:", barcode)
                    sql2 = "SELECT id,KMS FROM authorized WHERE VIN = %s"
                    cursor.execute(sql2, str(barcode))
                    result = cursor.fetchall()
                    print(result)
                    if not result:
                        sql1 = "INSERT INTO authorized (VIN) VALUES (%s)"
                        cursor.execute(sql1, str(barcode))
                        bc = barcode
                        f = 1
                        db.commit()
                    else:
                        print("Already in database")
                        sql4 = "SELECT left_at FROM authorized WHERE VIN = %s"
                        cursor.execute(sql4, str(barcode))
                        result1 = cursor.fetchall()
                        print(result1[0])
                        if not result1[0][0]:
                            ct = time.time()
                            formatted_ct = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ct))
                            print(formatted_ct)
                            sql3 = "UPDATE authorized SET left_at= %s where VIN=%s"
                            sqli= "SET SQL_SAFE_UPDATES = 0"
                            try:
                                cursor.execute(sqli)
                                cursor.execute(sql3, (formatted_ct,str(barcode)))
                                db.commit()
                            except Exception as e:
                                print(f"Error updating data: {str(e)}")
                            
                # elif (len(barcode) == 8 and not barcode.startswith("MA1")):
                #     barcode = "@"
                #     barcode2 = "@"
                #     sql1 = "INSERT INTO authorized (VIN,name_id) VALUES (%s,%s)"
                #     cursor.execute(sql1, (str(barcode),str(barcode2)))
                #     db.commit()

            if f == 1:
                barcode2 += char
                if(ft==0 and len(barcode2)>=7):
                    ft=1
                    tt= time.time()
                print(char, end='', flush=True)  # Print the typed character without newline
                print(tt - last_key_time)
                print(current_time - last_key_time>1.5)
                print(len(barcode2))
                if ((len(barcode2)>7 and barcode2.startswith('33')) and (last_key_time - tt > 1.5)) or barcode2=="VIPPASS":
                    print("\nCaptured barcode2:", barcode2)
                    barcode2 = re.sub('[^a-zA-Z]', '', barcode2)
                    print("\nInputted name:", barcode2)
                    sql1 = "UPDATE authorized SET name_id= %s where VIN=%s"
                    cursor.execute(sql1, (str(barcode2), str(bc)))
                    db.commit()
                    barcode = ""
                    barcode2 = ""
                    f = 0


    except AttributeError:
        if key == keyboard.Key.ctrl_l or key == keyboard.Key.ctrl_r or key == keyboard.KeyCode.from_char('/') or key == None:
            # Handle Ctrl or slash key separately or together as needed
            pass
        pass
##aksh-123
print("Type the barcode (press 'esc' to finish):") 

with keyboard.Listener(on_release=on_release) as listener:
    listener.join()
