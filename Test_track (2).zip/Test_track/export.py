import pandas as pd
import pymysql

# MySQL Connection Configuration
config = {
    'user': 'root',
    'password': '1234',
    'host': 'localhost',
    'database': 'db',
}

# Establishing MySQL Connection
try:
    conn = pymysql.connect(**config)
    cursor = conn.cursor()

    # Fetching data from MySQL
    query = "SELECT * FROM authorized WHERE VIN LIKE 'ma1%' AND CHAR_LENGTH(VIN) = 17"
    cursor.execute(query)

    # Extracting data into a pandas DataFrame
    data = cursor.fetchall()
    columns = [col[0] for col in cursor.description]
    df = pd.DataFrame(data, columns=columns)
    
    # Exporting data to Excel
    excel_file = "data_from_mysql.xlsx"
    df.to_excel(excel_file, index=False)

    print(f"Data successfully exported to '{excel_file}'")

except Exception as e:
    print (f'\'error\': {str(e)}')

finally:
    # Closing MySQL Connection
    if 'connection' in locals() and conn.open:
        conn.close()
